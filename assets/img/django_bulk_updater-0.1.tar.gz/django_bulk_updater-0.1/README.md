# django-multi-bulk-updater
